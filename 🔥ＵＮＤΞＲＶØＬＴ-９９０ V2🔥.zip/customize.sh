#!/system/bin/sh
# Customize script - shows warning if device is not Samsung Exynos 990
MODDIR=${0%/*}

# Get device brand and CPU
brand=$(getprop ro.product.brand)
cpu=$(getprop ro.board.platform)

# Only show warning if not Samsung or not Exynos990
if [ "$brand" != "samsung" ] || [ "$cpu" != "exynos990" ]; then
    ui_print "⚠️ WARNING: This module is designed for Samsung devices with Exynos 990!"
    ui_print "Installing on other devices may cause BOOTLOOP or BRICK!"
    ui_print "Proceed at your own risk."
fi
