-#!/system/bin/sh
# Undervolt Exynos 990 - KØRD edition - Stable Aggressive
# ⚡ Ajustado para manter agressividade sem freeze

# Percentuais de redução OPP
REDUCE_LITTLE=55
REDUCE_BIG=25
REDUCE_PRIME=15
REDUCE_MIF=40
REDUCE_INT=30
REDUCE_INTCAM=35
REDUCE_DISP=25
REDUCE_CAM=25
REDUCE_AUD=25
REDUCE_DSP=30
REDUCE_DNC=30
REDUCE_MFC=25
REDUCE_NPU=40
REDUCE_TNR=25

MIN_SAFE=600000

# === [1] Ajuste percent_margin ===
# CPU clusters - seguro
echo '-3' > /sys/power/percent_margin/big_margin_percent
echo '-3' > /sys/power/percent_margin/mid_margin_percent
echo '-3' > /sys/power/percent_margin/lit_margin_percent

# Aceleradores e blocos que aguentam agressivo
echo '-6' > /sys/power/percent_margin/mif_margin_percent
echo '-6' > /sys/power/percent_margin/npu_margin_percent
echo '-6' > /sys/power/percent_margin/score_margin_percent
echo '-6' > /sys/power/percent_margin/iva_margin_percent
echo '-6' > /sys/power/percent_margin/fsys0_margin_percent
echo '-6' > /sys/power/percent_margin/g3d_margin_percent
echo '-6' > /sys/power/percent_margin/mfc_margin_percent

# === [2] Função de undervolt ===
apply_undervolt() {
    local path="$1"
    local reduce="$2"

    if [ -f "$path/opp-microvolt" ]; then
        current=$(cat "$path/opp-microvolt")
        new=$(( current - (current * reduce / 100) ))

        if [ "$new" -lt "$MIN_SAFE" ]; then
            new=$MIN_SAFE
        fi

        echo $new > "$path/opp-microvolt" 2>/dev/null
        echo "[UV] $path: $current -> $new"
    fi
}

# === [3] Clusters CPU com schedutil + max clock apenas em BIG/PRIME ===
for cpu in 0 1 2 3; do
    echo schedutil > /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_governor
    echo 5000 > /sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil/up_rate_limit_us
    echo 5000 > /sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil/down_rate_limit_us
    for opp in /sys/kernel/debug/opp/cpu$cpu/opp:*; do
        apply_undervolt "$opp" $REDUCE_LITTLE
    done
done

for cpu in 4 5 6; do
    echo schedutil > /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_governor
    max_freq=$(cat /sys/devices/system/cpu/cpu$cpu/cpufreq/cpuinfo_max_freq)
    echo $max_freq > /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_max_freq
    echo 5000 > /sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil/up_rate_limit_us
    echo 5000 > /sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil/down_rate_limit_us
    for opp in /sys/kernel/debug/opp/cpu$cpu/opp:*; do
        apply_undervolt "$opp" $REDUCE_BIG
    done
done

echo schedutil > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
max_freq=$(cat /sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq)
echo $max_freq > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
echo 5000 > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/up_rate_limit_us
echo 5000 > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/down_rate_limit_us
for opp in /sys/kernel/debug/opp/cpu7/opp:*; do
    apply_undervolt "$opp" $REDUCE_PRIME
done

# === [4] Barramentos e aceleradores ===
for block in \
    "platform-17000010.devfreq_mif:$REDUCE_MIF" \
    "platform-17000020.devfreq_int:$REDUCE_INT" \
    "platform-17000030.devfreq_intcam:$REDUCE_INTCAM" \
    "platform-17000040.devfreq_disp:$REDUCE_DISP" \
    "platform-17000050.devfreq_cam:$REDUCE_CAM" \
    "platform-17000060.devfreq_aud:$REDUCE_AUD" \
    "platform-17000070.devfreq_dsp:$REDUCE_DSP" \
    "platform-17000080.devfreq_dnc:$REDUCE_DNC" \
    "platform-17000090.devfreq_mfc:$REDUCE_MFC" \
    "platform-170000a0.devfreq_npu:$REDUCE_NPU" \
    "platform-170000b0.devfreq_tnr:$REDUCE_TNR"
do
    IFS=":" read name reduce <<< "$block"
    for opp in /sys/kernel/debug/opp/$name/opp:*; do
        apply_undervolt "$opp" $reduce
    done
done

echo "✅ Undervolt agressivo ajustado para estabilidade - ready to war!"
