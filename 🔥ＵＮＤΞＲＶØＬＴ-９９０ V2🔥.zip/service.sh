#!/system/bin/sh
# Magisk service script - Extreme Pro V2.5
# Author: KØRD
# Runs on boot and calls the undervolt script only on Samsung Exynos 990

MODDIR=${0%/*}   # Module directory

# Delay to wait for sysfs initialization
sleep 5

# Get device brand and CPU platform
brand=$(getprop ro.product.brand)
cpu=$(getprop ro.board.platform)

# Only run undervolt if device is Samsung with Exynos 990
if [ "$brand" = "samsung" ] && [ "$cpu" = "exynos990" ]; then
    UV_SCRIPT="$MODDIR/undervolt.sh"
    if [ -f "$UV_SCRIPT" ]; then
        sh "$UV_SCRIPT"
    fi
fi
